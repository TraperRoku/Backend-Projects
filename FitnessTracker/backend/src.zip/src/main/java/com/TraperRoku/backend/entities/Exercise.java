package com.TraperRoku.backend.entities;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@Entity
@Table(name = "app_exercise")
public class Exercise {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id_exercise;

    private String nameExercise;

    private int sets;
    private int reps;

    @ManyToOne
    @JoinColumn(name = "workout_id")
    private Workout workout;
}
