    package com.TraperRoku.backend.controller;


    import com.TraperRoku.backend.Dto.UserDto;
    import com.TraperRoku.backend.entities.User;
    import com.TraperRoku.backend.entities.Workout;
    import com.TraperRoku.backend.service.JwtService;
    import com.TraperRoku.backend.service.UserService;
    import com.TraperRoku.backend.service.WorkoutService;
    import jakarta.servlet.http.HttpServletRequest;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.security.core.Authentication;
    import org.springframework.security.core.annotation.AuthenticationPrincipal;
    import org.springframework.security.core.context.SecurityContextHolder;
    import org.springframework.web.bind.annotation.*;

    import java.security.Principal;
    import java.time.LocalDate;
    import java.util.List;

    @RestController
    @RequestMapping("/api/workouts")
    public class WorkoutController {

        @Autowired
        public WorkoutService workoutService;

        @Autowired
        public UserService userService;

        @Autowired
        private JwtService jwtService;

        @GetMapping
        public List<Workout> getAllWorkouts(){
            return workoutService.getAllWorkouts();
        }

        @GetMapping("/week/{start}")
        public List<Workout> getWorkoutsForWeek(@PathVariable String start) {
            LocalDate weekStart = LocalDate.parse(start);
            return workoutService.getWorkoutsForWeek(weekStart);
        }

        @GetMapping("/{id}")
        public Workout getWorkoutById(@PathVariable Long id){
            return workoutService.getWorkoutById(id);
        }

        @PostMapping
        public Workout createWorkout(@RequestBody Workout workout, HttpServletRequest request) {

            String authorizationHeader = request.getHeader("Authorization");

            // Check if the header is valid (starts with "Bearer ")
            if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
                // Extract the token by removing the "Bearer " prefix
                String token = authorizationHeader.substring(7);

                // Print the received token for debugging purposes
                System.out.println("Received Token: " + token);  // Debug line

                // Use the JwtService to extract the login from the token
                String login = jwtService.extractLogin(token);

                // Retrieve the user from the service using the extracted login
                User user = userService.findByLogin1(login);
                workout.setUser(user);

                // Save the workout and return the response
                return workoutService.saveWorkout(workout);
            } else {
                // Handle case where the Authorization header is missing or malformed
                throw new RuntimeException("Authorization header is missing or invalid.");
            }
        }

        @DeleteMapping("{id}")
        public void deleteWorkoutById(@PathVariable Long id){
            workoutService.deleteWorkout(id);
        }
    }
