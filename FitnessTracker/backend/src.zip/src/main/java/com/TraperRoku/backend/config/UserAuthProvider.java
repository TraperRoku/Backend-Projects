package com.TraperRoku.backend.config;

import com.TraperRoku.backend.Dto.UserDto;
import com.TraperRoku.backend.service.UserService;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;


import java.util.Base64;
import java.util.Collections;
import java.util.Date;


@RequiredArgsConstructor
@Component
public class UserAuthProvider {

    private static final String SECRET_KEY = "mySecretKey123";  // Ensure it's the same key as used in verification

    private final UserService userService;

    public String createToken(String login) {
        Date now = new Date();
        Date validity = new Date(now.getTime() + 5_600_00);  // Set your desired expiration time

        // Use the raw secret key for signing
        String token =  JWT.create()
                .withIssuer(login)
                .withIssuedAt(now)
                .withExpiresAt(validity)
                .sign(Algorithm.HMAC256(SECRET_KEY));
        System.out.println("Generated Token: " + token);
        return token;
    }

    public Authentication validateToken(String token) {
        JWTVerifier verifier = JWT.require(Algorithm.HMAC256(SECRET_KEY)).build();  // Same key used for verification
        DecodedJWT decodedJWT = verifier.verify(token);
        UserDto user = userService.findByLogin(decodedJWT.getIssuer());
        return new UsernamePasswordAuthenticationToken(user, null, Collections.emptyList());
    }
}

