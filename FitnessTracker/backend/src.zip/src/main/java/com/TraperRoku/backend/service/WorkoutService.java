package com.TraperRoku.backend.service;


import com.TraperRoku.backend.entities.Workout;
import com.TraperRoku.backend.repository.WorkoutRepository;
import org.hibernate.jdbc.Work;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.List;


@Service
public class WorkoutService {
    @Autowired
    public WorkoutRepository workoutRepository;


    public List<Workout> getWorkoutsForWeek(LocalDate weekStart) {
        LocalDate weekEnd = weekStart.plusDays(6);
        return workoutRepository.findAllByDateBetween(weekStart, weekEnd);
    }

    public List<Workout> getAllWorkouts(){
        return workoutRepository.findAll();
    }

    public Workout getWorkoutById(Long Id){
        return workoutRepository.findById(Id).orElse(null);
    }

    public Workout saveWorkout(Workout workout){
        return workoutRepository.save(workout);
    }

  public void deleteWorkout(Long Id){
        workoutRepository.deleteById(Id);
  }

}
